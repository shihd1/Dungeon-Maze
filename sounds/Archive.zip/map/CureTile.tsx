<?xml version="1.0" encoding="UTF-8"?>
<tileset name="CureTile" tilewidth="16" tileheight="16" tilecount="6" columns="2">
 <image source="../sprites/CureTile.png" width="32" height="48"/>
 <tile id="0">
  <properties>
   <property name="collide" type="bool" value="true"/>
   <property name="cure" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="collide" type="bool" value="true"/>
   <property name="cure" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="collide" type="bool" value="true"/>
   <property name="cure" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="collide" type="bool" value="true"/>
   <property name="cure" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="collide" type="bool" value="true"/>
   <property name="cure" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
