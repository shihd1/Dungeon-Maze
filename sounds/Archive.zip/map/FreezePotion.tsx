<?xml version="1.0" encoding="UTF-8"?>
<tileset name="FreezePotion" tilewidth="16" tileheight="16" tilecount="1" columns="1">
 <image source="../sprites/FreezePotion.png" width="16" height="16"/>
 <tile id="0">
  <properties>
   <property name="sprite" value="sprites/FreezePotion.png"/>
  </properties>
 </tile>
</tileset>
