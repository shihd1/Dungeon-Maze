<?xml version="1.0" encoding="UTF-8"?>
<tileset name="WeirdCorners" tilewidth="16" tileheight="16" tilecount="12" columns="3">
 <image source="../sprites/WeirdCorners.png" width="48" height="64"/>
</tileset>
