<?xml version="1.0" encoding="UTF-8"?>
<tileset name="portal" tilewidth="16" tileheight="16" tilecount="2" columns="1">
 <image source="../sprites/portal.png" width="16" height="32"/>
 <tile id="1">
  <properties>
   <property name="trap" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
