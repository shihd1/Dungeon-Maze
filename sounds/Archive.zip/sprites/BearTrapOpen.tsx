<?xml version="1.0" encoding="UTF-8"?>
<tileset name="BearTrapOpen" tilewidth="16" tileheight="16" tilecount="1" columns="1">
 <properties>
  <property name="Trap" type="bool" value="true"/>
 </properties>
 <image source="BearTrapOpen.png" width="16" height="16"/>
 <tile id="0">
  <properties>
   <property name="Trap" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
