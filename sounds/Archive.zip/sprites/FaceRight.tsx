<?xml version="1.0" encoding="UTF-8"?>
<tileset name="FaceRight" tilewidth="16" tileheight="16" tilecount="1" columns="1">
 <image source="../sprites/FaceRight.png" width="16" height="16"/>
 <tile id="0">
  <properties>
   <property name="h" type="float" value="10.05"/>
   <property name="sprite" value="sprites/FaceRight.png"/>
   <property name="w" type="float" value="9.85"/>
   <property name="x" type="float" value="2.96"/>
   <property name="y" type="float" value="2.96"/>
  </properties>
  <objectgroup draworder="index">
   <object id="4" x="2.95546" y="2.95546" width="9.85154" height="10.0486">
    <properties>
     <property name="h" type="float" value="10.05"/>
     <property name="sprite" value="sprites/FaceRight.png"/>
     <property name="w" type="float" value="9.85"/>
     <property name="x" type="float" value="2.96"/>
     <property name="y" type="float" value="2.96"/>
    </properties>
   </object>
  </objectgroup>
 </tile>
</tileset>
