<?xml version="1.0" encoding="UTF-8"?>
<tileset name="GreenFrontBoy" tilewidth="16" tileheight="16" tilecount="1" columns="1">
 <properties>
  <property name="h" type="float" value="12"/>
  <property name="sprite" value="map/GreenFrontBoy.png"/>
  <property name="w" type="float" value="12"/>
  <property name="x" type="float" value="2"/>
  <property name="y" type="float" value="2"/>
 </properties>
 <image source="GreenFrontBoy.png" width="16" height="16"/>
 <tile id="0">
  <properties>
   <property name="h" type="float" value="16"/>
   <property name="isPlayer" type="bool" value="true"/>
   <property name="sprite" value="sprites/GreenFrontBoy.png"/>
   <property name="w" type="float" value="16"/>
   <property name="x" type="float" value="0"/>
   <property name="y" type="float" value="0"/>
  </properties>
  <objectgroup draworder="index">
   <object id="4" x="1.87179" y="0.0985154" width="11.9204" height="15.7625">
    <properties>
     <property name="h" value="16"/>
     <property name="isPlayer" type="bool" value="true"/>
     <property name="sprite" value="map/GreenFrontBoy.png"/>
     <property name="w" value="11.92"/>
     <property name="x" value="1.87"/>
     <property name="y" value="0.10"/>
    </properties>
   </object>
   <object id="10" x="1.97031" y="0.295546" width="12.0189" height="15.7625"/>
  </objectgroup>
 </tile>
</tileset>
